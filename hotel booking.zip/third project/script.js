document.getElementById('bookingForm')
.addEventListener('submit',function(event)
{
event.preventDefault();

const name = 
document.getElementById('name').Value;
const checkin =
document.getElementById('checkin').Value;
const checkout =
document.getElementById('checkout').Value;
const rooms =
document.getElementById('rooms').Value;

if(!name||!checkin||!checkout||rooms<=0){
    alert('please fill out all fields correctly.');
    return;

}

const confirmationMessage =`
Thank you,${rooms}room(s)has been recieved.`;

document.getElementById('confirmationMessage').innerText=confirmationMessage;


document.getElementById('bookingForm').requestFullscreen();


})